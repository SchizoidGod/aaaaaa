# -*- coding: utf-8 -*-
from __future__ import unicode_literals


from django.shortcuts import render
from django.http import HttpResponse


def home(request):
     return HttpResponse(u'Привет, Мир!',
content_type="text/plain")
# Create your views here.
