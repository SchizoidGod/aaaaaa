from django.apps import AppConfig


class AppNameConfig(AppConfig):
    name = 'app_name'
